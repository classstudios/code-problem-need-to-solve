// g190604/g190604.js

var wxDraw = require("wxdraw.min.js").wxDraw;
var Shape = require("wxdraw.min.js").Shape;
var arr1 = [];
var x1=0;
var y1=0
var i

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    wxCanvas: null //    需要创建一个对象来接受wxDraw对象

  },
  bindtouchstart: function (e) {
    // 检测手指点击开始事件
    this.wxCanvas.touchstartDetect(e);

  },
  bindtouchmove: function (e) {
    // 检测手指点击 之后的移动事件
    this.wxCanvas.touchmoveDetect(e);
  },
  bindtouchend: function () {
    //检测手指点击 移出事件
    this.wxCanvas.touchendDetect();
  },

  bindlongpress: function (e) {
    // 检测longpress事件
    this.wxCanvas.longpressDetect(e);
  },
  onLoad: function () {
    var context = wx.createCanvasContext('first');//还记得 在wxml里面canvas的id叫first吗
    this.wxCanvas = new wxDraw(context, 0, 0, 400, 500);
    //初始化wxDraw对象 注意这里除了context的四个参数 就是canvas的位置以及长宽，😏还记得吗？

    var enemy = new Shape('image', { x: 90, y: -160, w: 30, h: 35, file: "enemy.png" }, 'fill', true);
    let enemy2 = enemy.clone();
    let enemy3 = enemy.clone();
    let enemy4 = enemy.clone();
    let enemy5 = enemy.clone();

    let img = new Shape('image', { x: 200, y: 350, w: 30, h: 35, file: "feiji.png" }, 'fill', true)

    this.wxCanvas.add(img);
    this.wxCanvas.add(enemy);
    this.wxCanvas.add(enemy2);
    this.wxCanvas.add(enemy3);
    this.wxCanvas.add(enemy4);
    this.wxCanvas.add(enemy5);
    
    for (i=1;i<100;i++){

    var img2 = new Shape('image', { x: 5000, y: 5000, w: 10, h: 20, file: "bullet.png" }, 'fill', true);
  
    this.wxCanvas.add(img2);
  
    enemy2.updateOption({  x: 210, y: -350 });
    enemy3.updateOption({  x: 290, y: -230 });
    enemy4.updateOption({  x: 330, y: -100 });
    enemy5.updateOption({  x: 140, y: 0 });
    //console.log(img)

      enemy.animate({ y: "+=860" }, { duration: 17000 }).start(1);
      enemy2.animate({ y: "+=1050" }, { duration: 24000 }).start(1);
      enemy3.animate({ y: "+=930" }, { duration: 20000 }).start(1);
      enemy4.animate({ y: "+=800" }, { duration: 25000 }).start(1);
      enemy5.animate({ y: "+=700" }, { duration: 15000 }).start(1);
    }
    img.bind('tap', function (e) {
      
      //console.log(x1,y1)
      img2.updateOption({ x: x1, y: y1 });
      img2.animate({ y: "-=1000" }, { duration: 2000 }).start(1);
    });
   

  },
  bindtap: function (e) {
   
    this.wxCanvas.tapDetect(e);
    arr1=e.changedTouches[0];
   x1=arr1.clientX;
    y1 = arr1.clientY;
  },

  
})
//触碰, 计分