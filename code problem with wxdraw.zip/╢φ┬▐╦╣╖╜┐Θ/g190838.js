// pages/g190838/g190838.js
const app = getApp()
var wxDraw = require("wxdraw.min.js").wxDraw;
var Shape = require("wxdraw.min.js").Shape;
var AnimationFrame = require("wxdraw.min.js").AnimationFrame;
var button=false;
var i;
var x1;
Page({

  data: {
    userInfo: {},
    hasUserInfo: false,
    wxCanvas: null //    需要创建一个对象来接受wxDraw对象

  },
  bindtouchstart: function (e) {
    // 检测手指点击开始事件
    this.wxCanvas.touchstartDetect(e);

  },
  bindtouchmove: function (e) {
    // 检测手指点击 之后的移动事件
    this.wxCanvas.touchmoveDetect(e);
  },
  bindtouchend: function () {
    //检测手指点击 移出事件
    this.wxCanvas.touchendDetect();
  },

  bindlongpress: function (e) {
    // 检测longpress事件
    this.wxCanvas.longpressDetect(e);
  },
  
   
  onLoad: function () {
    var context = wx.createCanvasContext('background')
    this.wxCanvas = new wxDraw(context, 0, 0, 400, 500)
    var rect = new Shape('rect', { x: 100, y: 60, w: 60, h: 20, fillStyle: "#2FB8AC", rotate: Math.PI / 2 }, 'mix', true);
    this.wxCanvas.add(rect);
    
    var leftb = new Shape('rect', { x: 20, y: 490, w: 50, h: 50, fillStyle: "#FFFFFF", rotate: Math.PI / 2 }, 'mix', true);
    this.wxCanvas.add(leftb);

    var rightb = new Shape('rect', { x: 350, y: 490, w: 50, h: 50, fillStyle: "#FFFFFF", rotate: Math.PI / 2 }, 'mix', true);
    this.wxCanvas.add(rightb);

    for (i=1;i<100;i++){
      rect.animate({ y: "+=500" }, { duration: 17000 }).start(1);
    
   
    };
    leftb.bind('tap', function (e) {
      
      x1=rect.x-5;
      rect.updateOption({ x:10});
      
    });
    rightb.bind('tap', function (e) {
      
      x1=rect.x+5;
      rect.updateOption({ x:300});
      
    });
  
},
bindtap: function (e) {
   
  this.wxCanvas.tapDetect(e);
 
},

})